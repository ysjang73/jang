import audioop
from ctypes import *
import MicrophoneStream as MS
import grpc
import gigagenieRPC_pb2
import gigagenieRPC_pb2_grpc
import MicrophoneStream as MS
import user_auth as UA

HOST = 'gate.gigagenie.ai'
PORT = 4080

RATE = 16000
CHUNK = 512

ERROR_HANDLER_FUNC = CFUNCTYPE(None, c_char_p, c_int, c_char_p, c_int, c_char_p)
def py_error_handler(filename, line, function, err, fmt):
  pass
c_error_handler = ERROR_HANDLER_FUNC(py_error_handler)

asound = cdll.LoadLibrary('libasound.so')
asound.snd_lib_error_set_handler(c_error_handler)

def generate_request():
  with MS.MicrophoneStream(RATE, CHUNK) as stream:
    audio_generator = stream.generator()

    for content in audio_generator:
      message = gigagenieRPC_pb2.reqVoice()
      message.audioContent = content
      yield message

def get_grpc_stub():
  channel = grpc.secure_channel('{}:{}'.format(HOST, PORT), UA.getCredentials())
  stub = gigagenieRPC_pb2_grpc.GigagenieStub(channel)

  return stub

def get_text_from_voice():
  print ("\n\n음성인식을 시작합니다.\n\n종료하시려면 Ctrl+\ 키를 누루세요.\n\n\n")
  stub = get_grpc_stub()
  request = generate_request()
  resultText = ''

  for response in stub.getVoice2Text(request):
    if response.resultCd == 200: # partial 
      print('resultCd=%d | recognizedText= %s'
          % (response.resultCd, response.recognizedText))
      resultText = response.recognizedText
    elif response.resultCd == 201: # final
      print('resultCd=%d | recognizedText= %s'
          % (response.resultCd, response.recognizedText))
      resultText = response.recognizedText
      break
    else:
      print('resultCd=%d | recognizedText= %s'
          % (response.resultCd, response.recognizedText))
      break

  print ("\n\n인식결과: %s \n\n\n" % (resultText))
  return resultText

if __name__ == '__main__':
  print(get_text_from_voice())