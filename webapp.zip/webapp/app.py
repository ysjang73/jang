from flask import Flask, render_template, request
import RPi.GPIO as GPIO

app = Flask(__name__)

@app.route('/')
def main():
    state = request.args.get("state")
    return render_template("control_off.html", state=state)

@app.route('/on')
def on():
    state = request.args.get("state")
    return render_template('control_on.html', state='magenta')

@app.route('/off')
def off():
    state = request.args.get("state")
    return render_template('control_off.html', state='off')

@app.route('/red')
def red():
    return render_template('control_on.html', state='red')

@app.route('/green')
def green():
    return render_template('control_on.html', state='green')

@app.route('/blue')
def blue():
# GPIO.output(pins,True)
    return render_template('control_on.html', state='blue')

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)